<?php
session_start();
if (!isset($_SESSION['Username'])) {
echo "<script>alert('login first')</script>";
echo"<script>window.location='login.php'</script>";
    exit();
}
include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        .bbody {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .dashboard {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            margin-top: 100px;
        }
        .dashboard h2 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }
        p{
            align-items: center;
            margin-left: 170px;
        }
    </style>
    
</head>
<body class="bbody">
    <div class="dashboard">
        <h2>Welcome, <?php echo $_SESSION['Username']; ?></h2>

        <!-- You can add more content to the dashboard here -->
        <p>This is your beauty warehouse system. You can add  customer , product</p>
        <p>This system will help you to manage and generet report</p>
    </div>
</body>
</html>

<?php include 'footer.php'; ?>
