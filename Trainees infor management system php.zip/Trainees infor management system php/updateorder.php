<?php
include 'connection.php';
include 'header.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $order_number = $_POST['order_number'];
    $order_date = $_POST['order_date'];

    $sql = "UPDATE `order` SET order_date='$order_date' WHERE order_number='$order_number'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo "<script>alert('Order date updated successfully')</script>";
        echo "<script>window.location='diplayorder.php'</script>";
    } else {
        echo "<script>alert('Failed to update order date')</script>";
    }
}

// Fetch order date details based on ID
if (isset($_GET['order_number'])) {
    $order_number = $_GET['order_number'];
    $sql = "SELECT * FROM `order` WHERE order_number='$order_number'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Order Date</title>
    <style>
        .bg {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            margin-left: 500px;
            margin-top: 10%;
        }
        .form {
            display: flex;
            flex-direction: column;
        }
        .form input[type="date"], .form button {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form button {
            background-color: #5cb85c;
            color: white;
            border: none;
            cursor: pointer;
        }
        .form button:hover {
            background-color: #4cae4c;
        }
        .form h2 {
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body class="bg">
    <div class="container">
        <h2>Edit Order Date</h2>
        <form method="post" class="form">
            <input type="hidden" name="order_number" value="<?php echo $row['order_number']; ?>">
            <input type="date" name="order_date" value="<?php echo $row['order_date']; ?>" required>
            <button type="submit" name="update">Update</button>
        </form>
    </div>
</body>
</html>

<?php include 'footer.php'; ?>
