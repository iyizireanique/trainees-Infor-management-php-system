<?php
include 'header.php';
include 'connection.php';

// Initialize variables
$cust_id = $_GET['cust_id'];

// Fetch customer data based on cust_id
$query = mysqli_query($conn, "SELECT * FROM `customer` WHERE cust_id='$cust_id'");
$row = mysqli_fetch_assoc($query);

// Handle form submission
if (isset($_POST['update'])) {
    $cust_fname = $_POST['cust_fname'];
    $cust_lname = $_POST['cust_lname'];
    $location = $_POST['location'];
    $order_number = $_POST['order_number'];

    // Update customer record
    $update_query = "UPDATE `customer` SET `cust_fname`='$cust_fname', `cust_lname`='$cust_lname', `location`='$location', `order_number`='$order_number' WHERE cust_id='$cust_id'";
    $update_result = mysqli_query($conn, $update_query);

    if ($update_result) {
        echo "<script>alert('Customer order updated successfully')</script>";
        echo "<script>window.location='diplaycustomer.php'</script>";
    } else {
        echo "<script>alert('Failed to update customer order')</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Customer Order</title>
    <style>
        .bodyw {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            margin-left: 500PX;
            margin-top: 50px;
        }
        .form {
            display: flex;
            flex-direction: column;
        }
        .form input[type="text"], .form select, .form button {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form button {
            background-color: #5cb85c;
            color: white;
            border: none;
            cursor: pointer;
        }
        .form button:hover {
            background-color: #4cae4c;
        }
        .form h2 {
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body class="bodyq">
    <div class="container">
        <h2>Update Customer Order</h2>
        <form method="post" class="form">
            <input type="text" name="cust_fname" placeholder="First Name" value="<?php echo $row['cust_fname']; ?>" required>
                        <input type="text" name="cust_lname" placeholder="Last Name" value="<?php echo $row['cust_lname']; ?>" required>
                                    <input type="text" name="location" placeholder="Location" value="<?php echo $row['location']; ?>" required>
                                       <input type="text" name="ProductCode"   readonly placeholder="Location" value="<?php echo $row['ProductCode']; ?>" required>
                                      <select name="order_number" required>
<?php 
             // Retrieve all order numbers from the `order` table
             $query_order = mysqli_query($conn, "SELECT * FROM `order`");
             while ($order_row = mysqli_fetch_assoc($query_order)) {
                 $selected = ($order_row['order_number'] == $row['order_number']) ? 'selected' : '';
                 echo "<option value='" . $order_row['order_number'] . "' $selected>" . $order_row['order_number'] . "</option>";
             }
             ?>
</select>
<button type="submit" name="update">Update</button>
</form>
</div>

</body>
</html>
<?php include 'footer.php'; ?>
            
