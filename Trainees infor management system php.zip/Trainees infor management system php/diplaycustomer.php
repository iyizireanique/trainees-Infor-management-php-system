<?php
include 'header.php';
include 'connection.php';

// Fetch all customer orders
$query = mysqli_query($conn, "SELECT * FROM `customer`");

?>
<br><br><br><br><br>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display Customer Orders</title>
    <style>
        
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            margin-left: 20px;
            margin-inline-end: 20px;
        }

        table {
            width: 80%;
            border-collapse: collapse;
            margin-top: 20px;
            margin-left: 120px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #5cb85c;
            color: white;
        }
    </style>
    </style>
</head>
<body class="bod">
    <div class="container">
        <h2  style="margin-left:600px;">Customer Orders</h2>
                <button style="margin-left:1000px;  
    padding: 10px;
    border: none;
    background-color: #5cb85c;
    color: white;
    border-radius: 4px;
    font-size: 16px;
    font-weight: 500;
    cursor: pointer;"><a href="diplayproduct.php" >Create New</a></button>
        <table>
            <thead>
                <tr>
                    <th>Customer ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Location</th>
                    <th>Order Number</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($query)): ?>
                <tr>
                    <td><?php echo $row['cust_id']; ?></td>
                    <td><?php echo $row['cust_fname']; ?></td>
                    <td><?php echo $row['cust_lname']; ?></td>
                    <td><?php echo $row['location']; ?></td>
                    <td><?php echo $row['order_number']; ?></td>
                    <td class="action-buttons">
                        <a href="updatecustomer.php?cust_id=<?php echo $row['cust_id']; ?>">Update</a>
                        <a href="deletecustomer.php?cust_id=<?php echo $row['cust_id']; ?>">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php include 'footer.php'; ?>
