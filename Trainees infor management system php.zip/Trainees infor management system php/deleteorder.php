<?php
include 'connection.php';

// Check if id is provided via GET
if (isset($_GET['order_number'])) {
    $order_number = $_GET['order_number'];

    // Delete query
    $sql = "DELETE FROM `order` WHERE order_number=$order_number";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo "<script>alert('Order date deleted successfully')</script>";
        echo "<script>window.location='diplayorder.php'</script>";
    } else {
        echo "<script>alert('Failed to delete order date')</script>";
    }
}
?>
