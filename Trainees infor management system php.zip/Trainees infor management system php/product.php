
<?php
include 'connection.php';
include 'header.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ProductName = $_POST['ProductName'];
    $product_quantity = $_POST['product_quantity'];
    $Unity_price=$_POST['Unity_price'];
    $Total_price=$Unity_price * $product_quantity;


    $sql = "INSERT INTO `products`( `ProductName`, `product_quantity`, `Unity_price`, `Total_price`) VALUES ('$ProductName','$product_quantity','$Unity_price','$Total_price')";
    $query=mysqli_query($conn,$sql);

    if ($query) {
        echo "<script>alert('New records of product created successfully')</script>";
        echo "<script>window.location='diplayproduct.php'</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}


?>
<br><br><br>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PRODUCT </title>
    <style>
        .body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form {
            display: flex;
            flex-direction: column;
        }
        .form input[type="text"], form input[type="number"], form input[type="password"], form button {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form button {
            background-color: #5cb85c;
            color: white;
            border: none;
            cursor: pointer;
        }
        .form button:hover {
            background-color: #4cae4c;
        }
    </style>
</head>
<body class="body">
    <div class="container">
        <h2>Insert  Product Data</h2>
        <form  method="post" class="form">
            <input type="text" name="ProductName" placeholder="product name" required>
            <input type="text" name="product_quantity" placeholder="product_quantity" required>
            <input type="number" name="Unity_price" placeholder="Unity_price" required>

            <button type="submit">Submit</button>
        </form>
      
    </div>
</body>
</html>
<?php 
include 'footer.php'; ?>

