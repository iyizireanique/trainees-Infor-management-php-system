<?php 

require 'connection.php';
if (isset($_POST['submit'])) {
	$C_ID = $_POST['C_ID'];
	$ExamDate = $_POST['ExamDate'];
	$CR_Marks = $_POST['CR_Marks'];
	if ($CR_Marks>=70 && $CR_Marks<100) {
		$decision = "C";
	}
	else{
		$decision = "NYC";
	}
	$sql = "INSERT INTO candidate_result VALUES('','$C_ID','$ExamDate','$CR_Marks','$decision')";
	$result = mysqli_query($con,$sql);
	if ($result) {
		 echo "<script>alert('data added successful'); window.location='candidate_result.php'</script>";
	}
	else{
		echo "not inserted";
	}
}

 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Add Candidates result</title>
	<link rel="stylesheet" type="text/css" href="css/form.css">
</head>
<body>
    <form method="POST">
    	<center><h1>Regist Candidate</h1></center>
    	 <select name="C_ID">
            <option hidden>C_ID</option>
            <?php 
             
             $get = mysqli_query($con,"SELECT * FROM candidate");
             while ($row=mysqli_fetch_array($get)) {
              
             ?>
             <option value="<?php echo $row['C_ID'] ?>"><?php echo $row['C_FirstName']; ?></option>
         <?php } ?>
        </select>
        <input type="date" name="ExamDate">
        <input type="number" name="CR_Marks" placeholder="Enter Candidates Mrks" min="0" max="100">
        <button name="submit">Submit</button>
    </form>
</body>
</html>