<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        * {
            text-decoration: none;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        .bodyg {
            background-color: #f4f4f4;
        }
        nav {
            background-color: #333;
            color: #fff;
            padding: 10px 0;
        }
        nav ul {
            list-style: none;
            display: flex;
            justify-content: space-around;
            align-items: center;
        }
        nav ul li {
            margin: 0 10px;
        }
        nav ul li a {
            color: white;
            font-size: 16px;
            padding: 10px 15px;
            display: block;
        }
        nav ul li a:hover {
            background-color: #555;
            border-radius: 5px;
        }
        nav button {
            background-color: #5cb85c;
            border: none;
            color: white;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
        }
        nav button a {
            color: white;
            text-decoration: none;
        }
        nav button:hover {
            background-color: #4cae4c;
        }
    </style>
</head>
<body class="bodyg">
    <nav>
        <div>
            <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="diplayproduct.php">PRODUCTS</a></li>
                <li><a href="diplaycustomer.php">CUSTOMERS</a></li>
                <li><a href="diplayorder.php">ORDER</a></li>
                <li><a href="report.php">REPORT</a></li>
                <button><a href="logout.php">Logout</a></button>
            </ul>
        </div>
    </nav>
</body>
</html>
