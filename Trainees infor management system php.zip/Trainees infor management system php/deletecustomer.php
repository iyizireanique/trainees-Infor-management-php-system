<?php
include 'header.php';
include 'connection.php';


$cust_id = $_GET['cust_id'];


if (isset($cust_id)) {

    $delete_query = "DELETE FROM `customer` WHERE cust_id='$cust_id'";
    $delete_result = mysqli_query($conn, $delete_query);

    if ($delete_result) {
        echo "<script>alert('Customer order deleted successfully')</script>";
        echo "<script>window.location='diplaycustomer.php'</script>";
    } else {
        echo "<script>alert('Failed to delete customer order')</script>";
    }
} else {
    echo "<script>alert('No customer ID provided')</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Customer Order</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
        }
        .container h2 {
            margin-bottom: 20px;
        }
        .btn {
            background-color: #d9534f;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #c9302c;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Delete Customer Order</h2>
        <p>Are you sure you want to delete this customer order?</p>
        <form method="post">
            <button type="submit" class="btn" name="delete">Delete</button>
            <a href="displaycustomer.php" class="btn">Cancel</a>
        </form>
    </div>
</body>
</html>

<?php include 'footer.php'; ?>
