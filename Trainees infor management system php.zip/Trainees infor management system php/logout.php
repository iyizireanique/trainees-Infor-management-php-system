<?php
session_start();
session_destroy();
echo "<script>alert('logout successfuly')</script>";
echo "<script>window.location='login.php'</script>";
?>
