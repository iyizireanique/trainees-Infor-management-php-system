<?php 
include 'header.php';
include 'connection.php';

// Initialize variables
$ProductCode = $_GET['ProductCode'];

if (isset($_POST['customer'])) {
    $cust_fname = $_POST['cust_fname'];
    $cust_lname = $_POST['cust_lname'];
    $location = $_POST['location'];
    $ProductCode = $_POST['ProductCode'];
    $order_number = $_POST['order_number'];

    // Retrieve product details based on ProductCode
    $query = mysqli_query($conn, "SELECT * FROM `products` WHERE ProductCode='$ProductCode'");
    $result = mysqli_fetch_array($query);
    $ProductCode = $result['ProductCode'];

    if ($result) {
        // Check if order number exists in orders table
        $insert = mysqli_query($conn, "INSERT INTO `customer`( `cust_fname`, `cust_lname`, `location`, `ProductCode`, `order_number`) VALUES ('$cust_fname','$cust_lname','$location','$ProductCode','$order_number')");
        
        if ($insert) {
            echo "<script>alert('Customer order inserted successfully')</script>";
            echo "<script>window.location='diplaycustomer.php'</script>";
        } else {
            echo "<script>alert('Failed to insert customer order')</script>";
        }
    } else {
        echo "<script>alert('Order number does not exist')</script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Order</title>
    <style>
        .ba {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            margin-left: 500px;
            margin-top: 50px;
        }
        .form {
            display: flex;
            flex-direction: column;
        }
        .form input[type="text"], .form button {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form button {
            background-color: #5cb85c;
            color: white;
            border: none;
            cursor: pointer;
        }
        .form button:hover {
            background-color: #4cae4c;
        }
        .form h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .form select,
        .form input[type="date"] {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            width: 100%;
            box-sizing: border-box;
        }
        .form select {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background-image: url('data:image/svg+xml;utf8,<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M7 10l5 5 5-5z"/></svg>');
            background-repeat: no-repeat;
            background-position-x: calc(100% - 10px);
            background-position-y: 50%;
            background-size: 12px;
            padding-right: 30px;
        }
    </style>
</head>
<body class="ba">
    <div class="container">
        <h2>Insert Customer Order</h2>
        <form method="post" class="form">
            <input type="text" name="cust_fname" placeholder="First Name" required>
            <input type="text" name="cust_lname" placeholder="Last Name" required>
            <input type="text" name="location" placeholder="Location" required>
            <input type="hidden" name="ProductCode" value="<?php echo $ProductCode; ?>">
            <select name="order_number" required>
                <option value="">Select Order Number</option>
                <?php 
                // Retrieve all order numbers from the `order` table
                $query_order = mysqli_query($conn, "SELECT * FROM `order`");
                while ($row = mysqli_fetch_assoc($query_order)) {
                    echo "<option value='" . $row['order_number'] . "'>" . $row['order_number'] . "</option>";
                }
                ?>
            </select>
            <input type="date" name="order_date" required>
            <button type="submit" name="customer">Submit</button>
        </form>
    </div>
</body>
</html>

<?php include 'footer.php'; ?>
