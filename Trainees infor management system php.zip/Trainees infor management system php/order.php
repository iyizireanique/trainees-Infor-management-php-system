<?php 
include 'connection.php';
if (isset($_POST['order'])) {
    $order_date = $_POST['order_date'];
    $query = mysqli_query($conn, "INSERT INTO `order`( `order_date`) VALUES ('$order_date')");
    if ($query == true) {
        echo "<script>alert('Order date set successfully')</script>";
        echo "<script>window.location='diplayorder.php'</script>";
    } else {
        echo "<script>alert('Failed to set order date')</script>";
    }
}
?>
<!DOCTYPE html>
<?php include 'header.php'; ?>

<br><br><br><br><br><br>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Order Date</title>
    <style>
       .bodyq{
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 50vh;
            margin: 0;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            padding: 40px;
            margin-left: 500px;
        }
        .form {
            display: flex;
            flex-direction: column;
        }
        .form input[type="date"], .form button {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }
        .form button {
            background-color: #5cb85c;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
        .form button:hover {
            background-color: #4cae4c;
        }
        .form h2 {
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body class="bodyq">
    <div class="container">
        <h2>Insert Order Date</h2>
        <form method="post" class="form">
            <input type="date" name="order_date" required>
            <button type="submit" name="order">Submit</button>
        </form>
    </div>
</body>
</html>
<?php include 'footer.php'; ?>