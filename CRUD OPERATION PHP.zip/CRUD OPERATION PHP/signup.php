<?php
include 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $Username = $_POST['Username'];
    $Password = $_POST['Password'];

    $sql = "INSERT INTO Users (UserName, Password) VALUES ('$Username', '$Password')";

    if ($conn->query($sql) === TRUE) {
         echo "<script>alert('Registration successful')</script>";
          echo "<script>window.location='index.php'</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="register-form">
        <h2>Register</h2>
        <form  method="post">
            <input type="text" name="Username" placeholder="Username" required>
            <input type="password" name="Password" placeholder="Password" required>
            <button type="submit">Register</button>
        </form>
    </div>
</body>
</html>
