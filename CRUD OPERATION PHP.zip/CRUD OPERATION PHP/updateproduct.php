<?php
include 'connection.php';
include 'header.php';

// Check if ProductCode is provided via GET
if (isset($_GET['ProductCode'])) {
    $productCode = $_GET['ProductCode'];

    // Fetch product details based on ProductCode
    $sql = "SELECT * FROM product WHERE ProductCode=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $productCode);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    // Handle form submission for updating product
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $ProductName = $_POST['ProductName'];
        $product_quantity = $_POST['product_quantity'];
        $Unity_price = $_POST['Unity_price'];
        $Total_price = $Unity_price * $product_quantity;

        // Update query
        $sql_update = "UPDATE product SET ProductName=?, product_quantity=?, Unity_price=?, Total_price=? WHERE ProductCode=?";
        $stmt_update = mysqli_prepare($conn, $sql_update);
        mysqli_stmt_bind_param($stmt_update, "ssdss", $ProductName, $product_quantity, $Unity_price, $Total_price, $productCode);
        mysqli_stmt_execute($stmt_update);

        if (mysqli_stmt_affected_rows($stmt_update) > 0) {
            echo "<script>alert('Product updated successfully')</script>";
            echo "<script>window.location='diplayproduct.php'</script>";
        } else {
            echo "Error updating product: " . mysqli_error($conn);
        }

        mysqli_stmt_close($stmt_update);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Product</title>
    <style>
        .body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form {
            display: flex;
            flex-direction: column;
        }
        .form input[type="text"], .form input[type="number"], .form input[type="password"], .form button {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form button {
            background-color: #5cb85c;
            color: white;
            border: none;
            cursor: pointer;
        }
        .form button:hover {
            background-color: #4cae4c;
        }
    </style>
</head>
<body class="body">
    <div class="container">
        <h2>Edit Product</h2>
        <form method="post" class="form">
            <input type="hidden" name="ProductCode" value="<?php echo $row['ProductCode']; ?>">
            <input type="text" name="ProductName" placeholder="Product Name" value="<?php echo $row['ProductName']; ?>" required>
            <input type="text" name="product_quantity" placeholder="Product Quantity" value="<?php echo $row['product_quantity']; ?>" required>
            <input type="number" name="Unity_price" placeholder="Unit Price" value="<?php echo $row['Unity_price']; ?>" required>

            <button type="submit">Update</button>
        </form>
    </div>
</body>
</html>

<?php
include 'footer.php';
?>
