<?php
include 'header.php';
include 'connection.php';

// Fetch all customer orders
$query = mysqli_query($conn, "SELECT * FROM `campany`");

?>
<br><br><br><br><br>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display Campany Info</title>
    <style>
        
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            margin-left: 20px;
            margin-inline-end: 20px;
        }

        table {
            width: 80%;
            border-collapse: collapse;
            margin-top: 20px;
            margin-left: 120px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #5cb85c;
            color: white;
        }
    </style>
    </style>
</head>
<body class="bod">
    <div class="container">
        <h2  style="margin-left:600px;">Campany Info</h2>
                <button style="margin-left:1000px;  
    padding: 10px;
    border: none;
    background-color: #5cb85c;
    color: white;
    border-radius: 4px;
    font-size: 16px;
    font-weight: 500;
    cursor: pointer;"><a href="campany.php" >Create New</a></button>
        <table>
            <thead>
                <tr>
                    <th>Campany ID</th>
                    <th>Campany Name</th>
                    <th>Location </th>
                    <th>Telephone</th>
                   
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($query)): ?>
                <tr>
                    <td><?php echo $row['camp_id']; ?></td>
                    <td><?php echo $row['camp_name']; ?></td>
                    <td><?php echo $row['telephone']; ?></td>
                    <td><?php echo $row['camp_location']; ?></td>
                    
                    <td class="action-buttons">
                        <a href="updatecampany.php?camp_id=<?php echo $row['camp_id']; ?>">Update</a>
                        <a href="deletecampany.php?camp_id=<?php echo $row['camp_id']; ?>">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php include 'footer.php'; ?>
