<?php
include 'header.php';
include 'connection.php';

$sup_id = $_GET['sup_id'];

// Fetch supplier order details
$query = mysqli_query($conn, "SELECT * FROM `supplier` WHERE sup_id='$sup_id'");
$row = mysqli_fetch_assoc($query);

if (isset($_POST['update'])) {
    $sup_Fname = $_POST['sup_Fname'];
    $sup_Lname = $_POST['sup_Lname'];
    $sup_address = $_POST['sup_address'];
    $agreement_termination_date = $_POST['agreement_termination_date'];
    $ProductCode = $_POST['ProductCode'];
    $camp_id = $_POST['camp_id'];
    $sup_date = $_POST['sup_date'];
    $agreement_date = $_POST['agreement_date'];

    // Update supplier order
    $update = mysqli_query($conn, "UPDATE `supplier` SET `sup_Fname`='$sup_Fname', `sup_Lname`='$sup_Lname', `sup_address`='$sup_address', `sup_date`='$sup_date', `agreement_date`='$agreement_date', `agreement_termination_date`='$agreement_termination_date', `ProductCode`='$ProductCode', `camp_id`='$camp_id' WHERE sup_id='$sup_id'");

    if ($update) {
        echo "<script>alert('Supplier order updated successfully')</script>";
        echo "<script>window.location='diplaysupplier.php'</script>";
    } else {
        echo "<script>alert('Failed to update supplier order: " . mysqli_error($conn) . "')</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Supplier Order</title>
    <style>
         .ba {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            margin-left: 500px;
            margin-top: 10px;
        }
        .form {
            display: flex;
            flex-direction: column;
        }
        .form input[type="text"], .form button {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form button {
            background-color: #5cb85c;
            color: white;
            border: none;
            cursor: pointer;
        }
        .form button:hover {
            background-color: #4cae4c;
        }
        .form h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .form select,
        .form input[type="date"] {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            width: 100%;
            box-sizing: border-box;
        }
        .form select {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background-image: url('data:image/svg+xml;utf8,<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M7 10l5 5 5-5z"/></svg>');
            background-repeat: no-repeat;
            background-position-x: calc(100% - 10px);
            background-position-y: 50%;
            background-size: 12px;
            padding-right: 30px;
        }
    </style>
</head>
<body class="ba">
    <div class="container">
        <h2>Update Supplier Order</h2>
        <form method="post" class="form">
            <input type="text" name="sup_Fname" value="<?php echo $row['sup_Fname']; ?>" placeholder="sup_Fname" required>
            <input type="text" name="sup_Lname" value="<?php echo $row['sup_Lname']; ?>" placeholder="sup_Lname" required>
            <input type="text" name="sup_address" value="<?php echo $row['sup_address']; ?>" placeholder="sup_address" required>
            <input type="date" name="sup_date" value="<?php echo $row['sup_date']; ?>" required>
            <input type="date" name="agreement_date" value="<?php echo $row['agreement_date']; ?>" required>
            <input type="hidden" name="ProductCode" value="<?php echo $row['ProductCode']; ?>">
            <select name="camp_id" required>
                <option value="">Select Company Number</option>
                <?php 
                // Retrieve all order numbers from the `campany` table
                $query_order = mysqli_query($conn, "SELECT * FROM `campany`");
                while ($order_row = mysqli_fetch_assoc($query_order)) {
                    $selected = $order_row['camp_id'] == $row['camp_id'] ? 'selected' : '';
                    echo "<option value='" . $order_row['camp_id'] . "' $selected>" . $order_row['camp_id'] . "</option>";
                }
                ?>
            </select>
            <input type="date" name="agreement_termination_date" value="<?php echo $row['agreement_termination_date']; ?>" required>
            <button type="submit" name="update">Update</button>
        </form>
    </div>
</body>
</html>

<?php include 'footer.php'; ?>
