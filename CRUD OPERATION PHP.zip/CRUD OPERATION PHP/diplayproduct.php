<?php 

include 'header.php'; ?>

<br><br><br>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PRODUCT</title>
    <style>

        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            margin-left: 20px;
            margin-inline-end: 20px;
        }

        table {
            width: 80%;
            border-collapse: collapse;
            margin-top: 20px;
            margin-left: 120px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #5cb85c;
            color: white;
        }
    </style>
</head>
<body class="body">
    <div class="container">

        <h2  style="margin-left:600px;">Product List</h2>
        <button style="margin-left:1000px;  
    padding: 10px;
    border: none;
    background-color: #5cb85c;
    color: white;
    border-radius: 4px;
    font-size: 16px;
    font-weight: 500;
    cursor: pointer;"><a href="products.php" >Create New</a></button>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Total Price</th>
                    <th>Update</th>
                    <th>Delete</th>
                    <th>Customer</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include 'connection.php';
                $sql = "SELECT * FROM product";
                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                                <td>{$row['ProductCode']}</td>
                                <td>{$row['ProductName']}</td>
                                <td>{$row['product_quantity']}</td>
                                <td>{$row['Unity_price']}</td>
                                <td>{$row['Total_price']}</td>
                               <td><a href='updateproduct.php?ProductCode={$row['ProductCode']}'>Update</a></td>
                               <td><a href='deleteproduct.php?ProductCode={$row['ProductCode']}'>Delete</a></td>
                                <td><a href='Supplies.php?ProductCode={$row['ProductCode']}'>Create Supplier</a></td>


                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No Supplier found</td></tr>";
                }
                ?>
            </tbody>
        </table>

    </div>
</body>
</html>
<?php 
include 'footer.php'; 
?>