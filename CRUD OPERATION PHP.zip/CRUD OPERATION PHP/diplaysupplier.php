<?php
include 'header.php';
include 'connection.php';

// Fetch all supplier orders
$query = mysqli_query($conn, "SELECT * FROM `supplier`");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supplier Orders</title>
    <style>

        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 0px;
            margin-left: 20px;
            margin-inline-end: 20px;
        }

        table {
            width: 80%;
            border-collapse: collapse;
            margin-top: 20px;
            margin-left: 120px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #5cb85c;
            color: white;
        }
    </style>
</head>
<body>
        <div class="container">
    <h2 style="margin-left: 500px;">Supplier Orders</h2>
            <button style="margin-left:1000px;  
    padding: 10px;
    border: none;
    background-color: #5cb85c;
    color: white;
    border-radius: 4px;
    font-size: 16px;
    font-weight: 500;
    cursor: pointer;"><a href="diplayproduct.php" >Create New</a></button>
    <table>
        <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Address</th>
            <th>Supply Date</th>
            <th>Agreement Date</th>
            <th>Agreement Termination Date</th>
            <th>Product Code</th>
            <th>Company ID</th>
            <th>Actions</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($query)): ?>
        <tr>
            <td><?php echo $row['sup_id']; ?></td>
            <td><?php echo $row['sup_Fname']; ?></td>
            <td><?php echo $row['sup_Lname']; ?></td>
            <td><?php echo $row['sup_address']; ?></td>
            <td><?php echo $row['sup_date']; ?></td>
            <td><?php echo $row['agreement_date']; ?></td>
            <td><?php echo $row['agreement_termination_date']; ?></td>
            <td><?php echo $row['ProductCode']; ?></td>
            <td><?php echo $row['camp_id']; ?></td>
            <td>
                <a href="updatesupplier.php?sup_id=<?php echo $row['sup_id']; ?>">Update</a>
                <a href="deletesupplier.php?sup_id=<?php echo $row['sup_id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>
</body>
</html>

<?php include 'footer.php'; ?>
