<?php
include 'header.php';
include 'connection.php';

$sup_id = $_GET['sup_id'];

// Delete supplier order
$query = mysqli_query($conn, "DELETE FROM `supplier` WHERE sup_id='$sup_id'");

if ($query) {
    echo "<script>alert('Supplier order deleted successfully')</script>";
    echo "<script>window.location='diplaysupplier.php'</script>";
} else {
    echo "<script>alert('Failed to delete supplier order: " . mysqli_error($conn) . "')</script>";
}
?>

<?php include 'footer.php'; ?>
