<?php
include 'connection.php';


if (isset($_GET['ProductCode'])) {
    $productCode = $_GET['ProductCode'];

    // Perform delete query
    $sql = "DELETE FROM product WHERE ProductCode=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $productCode);
    mysqli_stmt_execute($stmt);

    // Check if deletion was successful
    if (mysqli_stmt_affected_rows($stmt) > 0) {
        echo "<script>alert('Product deleting successfully')</script>";
        echo "<script>window.location='diplayproduct.php'</script>";
        exit();
    } else {
        echo "Error deleting product.";
    }

    mysqli_stmt_close($stmt);
}
?>
