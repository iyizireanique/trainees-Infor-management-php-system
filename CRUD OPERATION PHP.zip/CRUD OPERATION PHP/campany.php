<?php 
include 'connection.php';
include 'header.php';
if (isset($_POST['customer'])) {
	$camp_name=$_POST['camp_name'];
	$telephone=$_POST['telephone'];
	$camp_location=$_POST['camp_location'];
	$query=mysqli_query($conn,"INSERT INTO `campany`( `camp_name`, `telephone`, `camp_location`) VALUES ('$camp_name','$telephone','$camp_location')");
	if ($query) {
	      echo "<script>alert('Campany  data set successfully')</script>";
            echo "<script>window.location='diplaycampany.php'</script>";
        } else {
            echo "Error set campany data: " . mysqli_error($conn);
        }
}

 ?>

 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Campany Info</title>
    <style>
        .ba {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            margin-left: 500px;
            margin-top: 50px;
        }
        .form {
            display: flex;
            flex-direction: column;
        }
        .form input[type="text"], .form button {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form button {
            background-color: #5cb85c;
            color: white;
            border: none;
            cursor: pointer;
        }
        .form button:hover {
            background-color: #4cae4c;
        }
        .form h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .form select,
        .form input[type="date"] {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            width: 100%;
            box-sizing: border-box;
        }
        .form select {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background-image: url('data:image/svg+xml;utf8,<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M7 10l5 5 5-5z"/></svg>');
            background-repeat: no-repeat;
            background-position-x: calc(100% - 10px);
            background-position-y: 50%;
            background-size: 12px;
            padding-right: 30px;
        }
    </style>
</head>
<body class="ba">
    <div class="container">
        <h2>Insert Campany infor</h2>
        <form method="post" class="form">
            <input type="text" name="camp_name" placeholder="campany_name" required>
            <input type="text" name="telephone" placeholder="telephone" required>
            <input type="text" name="camp_location" placeholder=" campany Location" required>
            <input type="hidden" name="ProductCode" value="<?php echo $ProductCode; ?>">

            <button type="submit" name="customer">Submit</button>
        </form>
    </div>
</body>
</html>

<?php include 'footer.php'; ?>
