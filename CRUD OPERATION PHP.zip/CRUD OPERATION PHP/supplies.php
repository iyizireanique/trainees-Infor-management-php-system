<?php 
include 'header.php';
include 'connection.php';

// Initialize variables
$ProductCode = $_GET['ProductCode'];
if (isset($_POST['supplier'])) {
    $sup_Fname = $_POST['sup_Fname'];
    $sup_Lname = $_POST['sup_Lname'];
    $sup_address = $_POST['sup_address'];
    $agreement_termination_date = $_POST['agreement_termination_date'];
    $ProductCode = $_POST['ProductCode'];
    $camp_id = $_POST['order_number'];  // Correcting the form field name
    $sup_date = $_POST['sup_date'];
    $agreement_date = $_POST['agreement_date'];

    // Retrieve product details based on ProductCode
    $query = mysqli_query($conn, "SELECT * FROM `product` WHERE ProductCode='$ProductCode'");
    $result = mysqli_fetch_array($query);

    if ($result) {
        // Check if order number exists in orders table
        $insert = mysqli_query($conn, "INSERT INTO `supplier` (`sup_Fname`, `sup_Lname`, `sup_address`, `sup_date`, `agreement_date`, `agreement_termination_date`, `ProductCode`, `camp_id`) VALUES ('$sup_Fname','$sup_Lname','$sup_address','$sup_date','$agreement_date','$agreement_termination_date','$ProductCode','$camp_id')");
        
        if ($insert) {
            echo "<script>alert('Supplier order inserted successfully')</script>";
            echo "<script>window.location='diplaysupplier.php'</script>";
        } else {
            echo "<script>alert('Failed to insert supplier order: " . mysqli_error($conn) . "')</script>";
        }
    } else {
        echo "<script>alert('Product does not exist')</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supplier Order</title>
    <style>
  .ba {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            margin-left: 500px;
            margin-top: 10px;
        }
        .form {
            display: flex;
            flex-direction: column;
        }
        .form input[type="text"], .form button {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form button {
            background-color: #5cb85c;
            color: white;
            border: none;
            cursor: pointer;
        }
        .form button:hover {
            background-color: #4cae4c;
        }
        .form h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .form select,
        .form input[type="date"] {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            width: 100%;
            box-sizing: border-box;
        }
        .form select {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background-image: url('data:image/svg+xml;utf8,<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M7 10l5 5 5-5z"/></svg>');
            background-repeat: no-repeat;
            background-position-x: calc(100% - 10px);
            background-position-y: 50%;
            background-size: 12px;
            padding-right: 30px;
        }
    </style>
</head>
<body class="ba">
    
    <div class="container">
        <h2>Insert Supplier Order</h2>
        <form method="post" class="form">
            <input type="text" name="sup_Fname" placeholder="sup_Fname" required>
            <input type="text" name="sup_Lname" placeholder="sup_Lname" required>
            <input type="text" name="sup_address" placeholder="sup_address" required>
            <input type="date" name="sup_date" required>
            <input type="date" name="agreement_date" required>
            <input type="hidden" name="ProductCode" value="<?php echo $ProductCode; ?>">
            <select name="order_number" required> <!-- Correcting the name attribute -->
                <option value="">Select Company Number</option>
                <?php 
                // Retrieve all order numbers from the `campany` table
                $query_order = mysqli_query($conn, "SELECT * FROM `campany`");
                while ($row = mysqli_fetch_assoc($query_order)) {
                    echo "<option value='" . $row['camp_id'] . "'>" . $row['camp_id'] . "</option>";
                }
                ?>
            </select>
            <input type="date" name="agreement_termination_date" required>
            <button type="submit" name="supplier">Submit</button>
        </form>
    </div>
</body>
</html>

<?php include 'footer.php'; ?>
