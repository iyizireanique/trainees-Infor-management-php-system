<?php
include 'connection.php';
session_start();
if (isset($_SESSION['Username'])) {
   echo "<script>alert('you logined alreday')</script>";
   echo"<script>window.location='index.php'</script>";

}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $Username = $_POST['Username'];
    $Password = $_POST['Password'];

    $sql = "SELECT * FROM Users WHERE UserName='$Username' AND Password='$Password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        session_start();
        $_SESSION['Username'] = $Username;
        echo "<script>alert('login succussfully')</script>";
       echo "<script>window.location='index.php'</script>";
    } else {
         echo "<script>alert('Invaild credits')</script>";
    }

    $conn->close();
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="login-form">
        <h2>Login</h2>
        <form action="login.php" method="post">
            <input type="text" name="Username" placeholder="Username" required>
            <input type="password" name="Password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
        <p>Don't have an account? <a href="signup.php">Register here</a></p>
    </div>
</body>
</html>
